export type ID = string | number;

export enum StatusPedido {
  PENDENTE = "PENDENTE",
  CONFIRMADO = "CONFIRMADO",
  CANCELADO = "CANCELADO",
  REAGENDADO = "REAGENDADO",
}

export interface Pedido {
  id: ID;
  aluno: string;
  fornecedor: string;
  dataEntrega: Date;
  status: StatusPedido;
}