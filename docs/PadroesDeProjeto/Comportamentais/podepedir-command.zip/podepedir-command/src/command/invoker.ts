import { Command } from "./command";

export class PedidoInvoker {
  private historico: Command[] = [];

  executar(cmd: Command) {
    console.log(`\n[Executando comando: ${cmd.descricao()}]`);
    cmd.execute();
    this.historico.push(cmd);
  }

  desfazerUltimo() {
    const cmd = this.historico.pop();
    if (!cmd) {
      console.log("Nenhum comando para desfazer.");
      return;
    }
    console.log(`\n[Desfazendo comando: ${cmd.descricao()}]`);
    cmd.undo();
  }

  listarHistorico() {
    console.log("\n=== Histórico de comandos ===");
    this.historico.forEach((c, i) =>
      console.log(`${i + 1}. ${c.descricao()}`)
    );
  }
}