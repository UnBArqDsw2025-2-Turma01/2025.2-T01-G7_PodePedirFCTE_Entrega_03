import { Command } from "./command";
import { PedidoService } from "../receiver/pedido-service";
import { StatusPedido } from "../domain";

export class ConfirmarPedidoCommand implements Command {
  private estadoAnterior: StatusPedido | null = null;
  constructor(private receiver: PedidoService) {}

  execute() {
    this.estadoAnterior = this.receiver.getStatus();
    this.receiver.confirmar();
  }

  undo() {
    if (this.estadoAnterior) {
      console.log(`↩️ Desfazendo confirmação...`);
      if (this.estadoAnterior === StatusPedido.PENDENTE)
        console.log(`Pedido voltou para PENDENTE.`);
    }
  }

  descricao() {
    return "Confirmar Pedido";
  }
}

export class CancelarPedidoCommand implements Command {
  private estadoAnterior: StatusPedido | null = null;
  constructor(private receiver: PedidoService) {}

  execute() {
    this.estadoAnterior = this.receiver.getStatus();
    this.receiver.cancelar();
  }

  undo() {
    if (this.estadoAnterior) {
      console.log(`↩️ Revertendo cancelamento...`);
      if (this.estadoAnterior === StatusPedido.PENDENTE)
        console.log(`Pedido voltou para PENDENTE.`);
    }
  }

  descricao() {
    return "Cancelar Pedido";
  }
}

export class ReagendarPedidoCommand implements Command {
  private estadoAnterior: StatusPedido | null = null;
  private dataAnterior: Date | null = null;

  constructor(private receiver: PedidoService, private novaData: Date) {}

  execute() {
    this.estadoAnterior = this.receiver.getStatus();
    this.dataAnterior = new Date();
    this.receiver.reagendar(this.novaData);
  }

  undo() {
    if (this.estadoAnterior && this.dataAnterior) {
      console.log(`↩️ Desfazendo reagendamento...`);
      console.log(`Pedido voltaria à data anterior: ${this.dataAnterior}`);
    }
  }

  descricao() {
    return "Reagendar Pedido";
  }
}