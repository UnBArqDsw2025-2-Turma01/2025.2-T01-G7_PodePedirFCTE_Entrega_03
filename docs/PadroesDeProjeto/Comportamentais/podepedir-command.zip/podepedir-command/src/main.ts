import { Pedido, StatusPedido } from "./domain";
import { PedidoService } from "./receiver/pedido-service";
import {
  ConfirmarPedidoCommand,
  CancelarPedidoCommand,
  ReagendarPedidoCommand,
} from "./command/concrete-commands";
import { PedidoInvoker } from "./command/invoker";

const pedido: Pedido = {
  id: "PED-2025-001",
  aluno: "Lucas Almeida",
  fornecedor: "Cantina FCTE",
  dataEntrega: new Date("2025-10-25"),
  status: StatusPedido.PENDENTE,
};

const service = new PedidoService(pedido);
const invoker = new PedidoInvoker();

// Criação dos comandos
const cmdConfirmar = new ConfirmarPedidoCommand(service);
const cmdReagendar = new ReagendarPedidoCommand(service, new Date("2025-10-28"));
const cmdCancelar = new CancelarPedidoCommand(service);

// Execução sequencial
invoker.executar(cmdConfirmar);
invoker.executar(cmdReagendar);
invoker.executar(cmdCancelar);

// Histórico e desfazer
invoker.listarHistorico();
invoker.desfazerUltimo();