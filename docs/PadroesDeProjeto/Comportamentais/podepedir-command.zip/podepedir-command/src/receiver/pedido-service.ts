import { Pedido, StatusPedido } from "../domain";

export class PedidoService {
  constructor(private pedido: Pedido) {}

  confirmar() {
    if (this.pedido.status === StatusPedido.CONFIRMADO) {
      console.log(`Pedido ${this.pedido.id} já está confirmado.`);
      return;
    }
    this.pedido.status = StatusPedido.CONFIRMADO;
    console.log(`✅ Pedido ${this.pedido.id} confirmado.`);
  }

  cancelar() {
    if (this.pedido.status === StatusPedido.CANCELADO) {
      console.log(`Pedido ${this.pedido.id} já está cancelado.`);
      return;
    }
    this.pedido.status = StatusPedido.CANCELADO;
    console.log(`🚫 Pedido ${this.pedido.id} cancelado.`);
  }

  reagendar(novaData: Date) {
    this.pedido.status = StatusPedido.REAGENDADO;
    this.pedido.dataEntrega = novaData;
    console.log(
      `📅 Pedido ${this.pedido.id} reagendado para ${novaData.toLocaleDateString()}.`
    );
  }

  getStatus() {
    return this.pedido.status;
  }
}
